print("suma: ")

numero_uno = 5
numero_dos = 4

resultado = numero_uno + numero_dos
print("El resultado de la suma es: " + str(resultado))


print("resta: ")

numero_uno = 5
numero_dos = 4

resultado = numero_uno - numero_dos
print("El resultado de la resta es: " + str(resultado))


print("multiplicación: ")

numero_uno = 5
numero_dos = 4

resultado = numero_uno * numero_dos
print("El resultado de la multiplicación es: " + str(resultado))


print("exponente: ")

numero_uno = 2
exponente = 5

resultado = numero_uno ** exponente  # Aquí corregí el exponente
print("El resultado del exponente es: " + str(resultado))


print("division: ")

numero_uno = 4
numero_dos = 2

resultado = numero_uno / numero_dos
print("El resultado de la división es: " + str(resultado))


print("módulo: ")

numero_uno = 30
numero_dos = 8

resultado = numero_uno % numero_dos
print("El resultado del módulo es: " + str(resultado))


print("división entera: ")

numero_uno = 4
numero_dos = 2

resultado = numero_uno // numero_dos
print("El resultado de la división entera es: " + str(resultado))