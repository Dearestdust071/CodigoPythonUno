print("\nEjercicio #4")

# Diccionario con frutas y sus respectivas cantidades
fruits = {
    "manzanas": 5,
    "peras": 2,
    "naranjas": 4
}

# Imprime el diccionario completo
print(fruits)

# Convierte las claves del diccionario en una lista
keys_list = list(fruits.keys())
print(f"Lista de claves: {keys_list}")

# Convierte los valores del diccionario en una lista
values_list = list(fruits.values())
print(f"Lista de valores: {values_list}")