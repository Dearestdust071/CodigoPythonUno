# Matriz de ejemplo
matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]

# Mostrar la matriz completa
print(f"{matrix[0]} \n{matrix[1]} \n{matrix[2]}")

# Mostrar el número 1 (ubicado en la primera fila, primera columna)
print(matrix[0][0])

# Mostrar el número 4 (ubicado en la segunda fila, primera columna)
print(matrix[1][0])

# Mostrar el número 8 (ubicado en la tercera fila, segunda columna)
print(matrix[2][1])

# Mostrar el número 3 (ubicado en la primera fila, tercera columna)
print(matrix[0][2])