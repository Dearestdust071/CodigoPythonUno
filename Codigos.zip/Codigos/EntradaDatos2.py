# El siguiente código pide al usuario que ingrese un dato y lo guarda en la variable 'nombre'
nombre = input()  # Muestra una solicitud para que el usuario ingrese algo y lo guarda en la variable 'nombre'

