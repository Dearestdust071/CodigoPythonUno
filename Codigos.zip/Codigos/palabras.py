# Definimos la variable prinT con valor 5
prinT = 5

# Definimos la variable Print con valor 6
Print = 6

# Sumar las dos variables
resultado = prinT + Print

# Imprimir el resultado de la suma
print(resultado)  # Esto imprimirá 11