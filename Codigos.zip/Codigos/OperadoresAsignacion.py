nombre = "Hola "
nombre += input("Escribe tu nombre: ")

print(nombre, ", esto es el incremento y decremento de una variable \n")

# Incremento o aumento
print("Incremento o aumento: ")
x = 1
print("El valor inicial de x es: ", x)

# Realizamos 4 incrementos
x += 1
x += 1
x += 1
x += 1
print("El valor final de x después de incrementar 4 veces es: ", x, "\n")

# Decremento o disminución
print("Decremento o disminución: ")
print("El valor inicial de x es: ", x)

# Realizamos 4 decrementos
x -= 1
x -= 1
x -= 1
x -= 1
print("El valor final de x después de decrementar 4 veces es: ", x)