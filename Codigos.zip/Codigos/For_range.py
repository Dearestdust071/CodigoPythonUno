# El ciclo 'for' recorre los números desde 1 hasta 4 (el 5 no es incluido)
for indice in range(1, 5):  # 'range(1, 5)' genera los números 1, 2, 3, 4
    # Imprime el valor de 'indice' en cada iteración
    print(indice)

# Imprime un mensaje indicando que el programa ha finalizado
print("Fin del programa.")