# La función len() se utiliza para obtener la longitud de un objeto como una cadena, lista, tupla, etc.

# Opción 1: Calcular y mostrar directamente la longitud de una cadena.
print("Hola tiene", len("Hola"), "caracteres.")

# Opción 2: Calcular la longitud de una cadena y almacenarla en una variable para usarla posteriormente.
longitud = len("La Geekipedia")
print("La Geekipedia tiene", longitud, "caracteres.")