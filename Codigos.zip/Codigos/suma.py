print("Esto es una suma")  # Muestra un mensaje explicativo
numero_uno = 2              # Asigna el valor 2 a la variable numero_uno
numero_dos = 4              # Asigna el valor 4 a la variable numero_dos
resultado = numero_uno + numero_dos  # Suma las dos variables
print(resultado)            # Muestra el resultado de la suma