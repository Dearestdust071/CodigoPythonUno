string = "Hola"

# El ciclo 'for' recorre cada caracter en la cadena 'string'
for character in string:
    # En cada iteración, imprime el caracter actual de la cadena
    print(character)

# Imprime un mensaje indicando que el programa ha finalizado
print("Fin del programa,.")