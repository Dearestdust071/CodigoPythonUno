# Tipo de dato entero o largo (long)
numero = 15
print(numero, type(numero))

# Tipo de dato flotante o real
numero_flotante = 15.5
print(numero_flotante, type(numero_flotante))

# Tipo de dato complejo
numero_complejo = 5 + 6j
print(numero_complejo, type(numero_complejo))

# Tipo de dato string o de cadena
nombre = "Ernesto"
print(nombre, type(nombre))

# Tipo de dato booleano
verdadero_falso = 3 == 3
print(verdadero_falso, type(verdadero_falso))