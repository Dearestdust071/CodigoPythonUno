
# A traves del caracter "#" al inicio de cada linea o antes del comentario se puede comentar el codigo tambien se pueden usar en mitad de lineas
#esto es un comentario alv
print("Hola") # ejemplo de comentar adelante de codigo
