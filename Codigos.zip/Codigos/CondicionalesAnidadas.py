print("=====================")
print("conversor")
print("=====================/n")


print("Menú de opciones: /n")
print("Presiona 1 para convertir de numero a palabra.")
print("Presiona 2 para convertir de palabra a numero")

opcion = int(input("¿Cual es tu opcion deseada?"))


# Este codigo tiene un menu para transformar palabras a numeros y numeros a palabras y aqui se demuestra el uso de anidar ifs and elifs

if opcion ==1:
    print("/n Conversor de numero a palabra. /n")

    opcion_uno = int(input("¿Cual es el numero que deseas comvertir a palabra?: "))

    # Aqui se crean diferentes if y elifs para comparar cual es el valor de la variable "opcion_uno" para imprimir si es Uno dos tres cuatro o cino
    if opcion_uno == 1:
        print("El numero es 'UNO'")
        # Aqui se usan opciones de elif (son similares al if pero solo se pueden usar posterior a un if)
    elif  opcion_uno == 2:
        print("El numero es 'DOS'")
    elif  opcion_uno == 3:
        print("El numero es 'TRES'")
    elif  opcion_uno == 4:
        print("El numero es 'CUATRO'")
    elif  opcion_uno == 5:
        print("El numero es 'CINCO'")
        # En caso de que ninguno de los casos anteriores haya sido verdadero se ejecutara la siguiente linea de codigo 
    else:
        print("El numero seleccionado no esta registrado")
        

# La misma cosa que el codigo anterior sin embargo en este caso la opcion a evaluar ahora sera un string
elif opcion == 2:
    print("/n conversor de palabra a numero. /n")

    opcion_dos = input("¿Cual es la palabra que deseas convertir a numero?: ")

    if opcion_dos == "uno":
        print("El numero es '1'")
    elif opcion_dos == "dos":
        print("El numero es '2'")
    elif  opcion_dos == "tres":
        print("El numero es '3'")
    elif  opcion_dos == "cuatro":
        print("El numero es '4'")
    elif  opcion_dos == "cinco":
        print("El numero es '5'")
    else:
        print("El numero seleccionado no esta registrado")

# Este else es seguido del if elif inicial comparando que tipo de traduccion querria hacer el usuario en caso de que ninguna de las opciones se encuentre
# Se seleccionara este bloque de codigo 
else:
    print("opcion no disponible.")
    

